const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("ans_btn");
const nextButton = document.getElementById("next");


const questions = [
    {
        question:"Capital City of Pakinstan:" ,
        answers:[
        {text: "Lahore" , correct: false },
        {text: "Karachi" , correct: false },
        {text: "Islamabad" , correct: true },
        {text: "Peshawar"  , correct: false }
        ]
    },
    {
        question:"Independence Day of Pakistan:",
        answers:[
        {text: "9th November", correct: false },
        {text: "14th August" , correct: true },
        {text: "23rd March", correct: false },
        {text: "25th December" , correct: false }
        ]
    },
    {
        question:"Provinces Of Pakistan:",
        answers:[
        {text: "4" , correct: false },
        {text: "8" , correct: false },
        {text: "5" , correct: true },
        {text: "6" , correct: false }
        ]
    },
    {
        question:"Founder Of Pakistan:",
        answers:[
        {text: "Quaid.e.Azam" , correct: true },
        {text: "Allama Iqbal" , correct: false },
        {text: "Liaquat Ali Khan" , correct: false },
        {text: "Sir Syed Ahmad Khan" , correct: false }
        ]
    },
    {
        question:"Revolution of Pakistan",
        answers:[
        {text: "9th November", correct: false },
        {text: "6th September" , correct: false },
        {text: "25th December" , correct: false },
        {text: "23rd March", correct: true }
        ]
    }
];

let currentQuestionIndex = 0;
let score = 0 ;

 function startQuiz(){
    currentQuestionIndex = 0;
    score = 0;
    next.innerHTML = "Next"
    showQuestion();
 }

 function showQuestion(){
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionNo = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNo + ". " + currentQuestion
    .question;

    currentQuestion.answers.forEach( answer => {
        const button = document.createElement("button");
        button.innerHTML = answer.text;
        button.classList.add("btn");
        answerButtons.appendChild(button);
        if(answer.correct){
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click" , selectAnswer);
    });
 }

 function resetState(){
    nextButton.style.display = "";
    while(answerButtons.firstChild){
        answerButtons.removeChild(answerButtons.firstChild);
    }
 }
function selectAnswer (e){
    const selectedBtn = e.target;
    const isCorrect = selectedBtn.dataset.correct === "true"
if (isCorrect){
    selectedBtn.classList.add("correct");
    score++;
}else{
    selectedBtn.classList.add("incorrect");
}Array.from(answerButtons.children).forEach(button => {
    if (button.dataset.correct === "true"){
        button.classList.add("correct");
    }
    button.disabled = true;
});
next.style.display = "block";
}
function showScore(){
    resetState();
questionElement.innerHTML = `You scored ${score} out of ${questions.length}!`;
nextButton.innerHTML = "Play Again";
nextButton.style.display = "block";
}

function handleNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex < questions.length){
        showQuestion();
    }else{
        showScore();
    }
}
next.addEventListener("click" , ()=>{
    if(currentQuestionIndex < questions.length){
        handleNextButton();
    }else{
        startQuiz();
    }
});

startQuiz();